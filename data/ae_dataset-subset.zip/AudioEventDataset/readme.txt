# Acoustic Event Dataset
# This dataset was harvested from fressound (https://www.freesound.org/).
# This dataset consists of 28 classes acoustic event sounds.

train: training samples
tets : testing samples

Full dataset can be found,
https://data.vision.ee.ethz.ch/cvl/ae_dataset/ae_dataset.zip

This data-subset was created for bert
https://github.com/jbcurtin/bert
